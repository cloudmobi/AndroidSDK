package com.cloudtech.mediation.mopub;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import com.cloudtech.ads.callback.CTAdEventListener;
import com.cloudtech.ads.core.CTNative;
import com.cloudtech.ads.core.CTService;
import com.cloudtech.ads.enums.AdSize;
import com.cloudtech.ads.vo.AdsNativeVO;
import com.mopub.mobileads.AdViewController;
import com.mopub.mobileads.CustomEventBanner;
import com.mopub.mobileads.MoPubErrorCode;
import java.util.Map;

public class CTAdapterBanner extends CustomEventBanner {

    private LinearLayout mInternalView;
    private ViewGroup decorView;
    private static final String TAG = "CTAdapterBanner";
    @Override
    protected void loadBanner(final Context context, final CustomEventBannerListener customEventBannerListener, Map<String, Object> localExtras, Map<String, String> serverExtras) {
        final String adUnitId;
        Log.e(TAG, "loadBanner: localExtras -> " + localExtras + ", serverExtras -> " + serverExtras);

        if (extrasAreValid(serverExtras) && context instanceof Activity) {
            adUnitId = serverExtras.get(CTHelper.KEY_CT_SLOTID);
        } else {
            customEventBannerListener.onBannerFailed(MoPubErrorCode.INTERNAL_ERROR);
            return;
        }

        CTService.init(context, adUnitId);

        decorView = (ViewGroup) (((Activity) context).getWindow().getDecorView());

        mInternalView = new LinearLayout(context);

        AdSize ctAdSize = AdSize.AD_SIZE_320X50;

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dpToPx(ctAdSize.getWidth()), dpToPx(ctAdSize.getHeight()));
        lp.gravity = Gravity.CENTER_HORIZONTAL;

        mInternalView.setLayoutParams(lp);

        AdViewController.setShouldHonorServerDimensions(mInternalView);

        decorView.addView(mInternalView);

        CTService.getMRAIDBanner((Activity) context, adUnitId, mInternalView, ctAdSize,
            new CTAdEventListener() {
                @Override
                public void onAdviewGotAdSucceed(CTNative ctNative) {
                    if (mInternalView != null) {
                        decorView.removeView(mInternalView);
                    }
                    if (ctNative != null) {
                        mInternalView.addView(ctNative);
                        customEventBannerListener.onBannerLoaded(mInternalView);
                    } else {
                        customEventBannerListener.onBannerFailed(
                            MoPubErrorCode.NETWORK_INVALID_STATE);
                    }
                }


                @Override
                public void onInterstitialLoadSucceed(CTNative ctNative) {
                }


                @Override
                public void onAdviewGotAdFail(CTNative ctNative) {
                    if (mInternalView != null) {
                        decorView.removeView(mInternalView);
                    }
                    customEventBannerListener.onBannerFailed(MoPubErrorCode.NETWORK_NO_FILL);
                }


                @Override
                public void onAdviewIntoLandpage(CTNative ctNative) {
                }


                @Override
                public void onStartLandingPageFail(CTNative ctNative) {
                }


                @Override
                public void onAdviewDismissedLandpage(CTNative ctNative) {
                }


                @Override
                public void onAdviewClicked(CTNative ctNative) {
                    customEventBannerListener.onBannerClicked();
                }


                @Override
                public void onAdviewClosed(CTNative ctNative) {
                    customEventBannerListener.onBannerCollapsed();
                }


                @Override
                public void onAdviewDestroyed(CTNative ctNative) {
                }


                @Override
                public void onAdsVoGotAdSucceed(AdsNativeVO adsNativeVO) {

                }
            });
    }


    @Override
    protected void onInvalidate() {
        mInternalView.removeAllViews();
        mInternalView = null;
    }


    private boolean extrasAreValid(final Map<String, String> serverExtras) {
        return (serverExtras != null) && serverExtras.containsKey(CTHelper.KEY_CT_SLOTID);
    }


    private int dpToPx(int dp) {
        DisplayMetrics displayMetrics = Resources.getSystem().getDisplayMetrics();
        return (int) (dp * displayMetrics.density + .5f);
    }
}
