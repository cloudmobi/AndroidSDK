package com.cloudtech.mediation.mopub;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.util.Log;
import com.cloudtech.ads.callback.VideoAdLoadListener;
import com.cloudtech.ads.core.CTError;
import com.cloudtech.ads.core.CTService;
import com.cloudtech.ads.core.CTVideo;
import com.cloudtech.videoads.core.CTServiceVideo;
import com.cloudtech.videoads.core.VideoAdListener;
import com.mopub.common.LifecycleListener;
import com.mopub.common.MoPubReward;
import com.mopub.common.logging.MoPubLog;
import com.mopub.mobileads.CustomEventRewardedVideo;
import com.mopub.mobileads.MoPubErrorCode;
import com.mopub.mobileads.MoPubRewardedVideoManager;
import java.util.Map;

public class CTAdapterRewardedVideo extends CustomEventRewardedVideo {
    private CTVideo video;
    private String adUnitId;

    private static final String TAG = "CTAdapterRewardedVideo";
    @Override
    @NonNull
    public LifecycleListener getLifecycleListener() {
        return new LifecycleListener() {
            @Override
            public void onCreate(@NonNull Activity activity) {

            }


            @Override
            public void onStart(@NonNull Activity activity) {

            }


            @Override
            public void onPause(@NonNull Activity activity) {

            }


            @Override
            public void onResume(@NonNull Activity activity) {

            }


            @Override
            public void onRestart(@NonNull Activity activity) {

            }


            @Override
            public void onStop(@NonNull Activity activity) {

            }


            @Override
            public void onDestroy(@NonNull Activity activity) {

            }


            @Override
            public void onBackPressed(@NonNull Activity activity) {

            }
        };
    }


    @Override
    @NonNull
    public String getAdNetworkId() {
        return adUnitId;
    }


    @Override
    public boolean checkAndInitializeSdk(@NonNull final Activity launcherActivity,
                                         @NonNull final Map<String, Object> localExtras,
                                         @NonNull final Map<String, String> serverExtras) {
        Log.e(TAG, "checkAndInitializeSdk: localExtras -> " + localExtras + ", serverExtras -> " + serverExtras);
        if (!CTHelper.extrasAreValid(serverExtras)) {
            return false;
        }
        String adUnitId = serverExtras.get(CTHelper.KEY_CT_SLOTID);
        CTService.init(launcherActivity, adUnitId);
        return true;
    }


    @Override
    protected void loadWithSdkInitialized(@NonNull Activity activity,
                                          @NonNull Map<String, Object> localExtras,
                                          @NonNull Map<String, String> serverExtras) {
        Log.e(TAG, "loadWithSdkInitialized: localExtras -> " + localExtras + ", serverExtras -> " + serverExtras);
        if (!CTHelper.extrasAreValid(serverExtras)) {
            MoPubRewardedVideoManager.onRewardedVideoLoadFailure(CTAdapterRewardedVideo.class, "",
                MoPubErrorCode.NETWORK_NO_FILL);
            return;
        }
        adUnitId = serverExtras.get(CTHelper.KEY_CT_SLOTID);

        CTServiceVideo.preloadRewardedVideo(activity, adUnitId,
            new VideoAdLoadListener() {
                @Override
                public void onVideoAdLoaded(CTVideo videoAd) {
                    video = videoAd;
                    MoPubRewardedVideoManager.onRewardedVideoLoadSuccess(
                        CTAdapterRewardedVideo.class, adUnitId);
                }


                @Override
                public void onVideoAdLoadFailed(CTError error) {
                    MoPubRewardedVideoManager.onRewardedVideoLoadFailure(
                        CTAdapterRewardedVideo.class, adUnitId,
                        MoPubErrorCode.NETWORK_NO_FILL);

                }
            });
    }


    @Override
    public boolean hasVideoAvailable() {
        return CTServiceVideo.isRewardedVideoAvailable(video);
    }


    @Override
    public void showVideo() {
        if (hasVideoAvailable()) {
            CTServiceVideo.showRewardedVideo(video, new VideoAdListener() {
                @Override
                public void videoPlayBegin() {
                    MoPubRewardedVideoManager.onRewardedVideoStarted(CTAdapterRewardedVideo.class,
                        adUnitId);
                }


                @Override
                public void videoPlayFinished() {
                }


                @Override
                public void videoPlayError(Exception e) {
                    MoPubRewardedVideoManager.onRewardedVideoPlaybackError(
                        CTAdapterRewardedVideo.class, adUnitId, MoPubErrorCode.VIDEO_NOT_AVAILABLE);
                }


                @Override
                public void videoClosed() {
                    MoPubRewardedVideoManager.onRewardedVideoClosed(CTAdapterRewardedVideo.class,
                        adUnitId);
                }


                @Override
                public void onRewardedVideoAdRewarded(String rewardName, String rewardAmount) {
                    int amount = 0;
                    try {
                        amount = Integer.parseInt(rewardAmount);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                    }
                    MoPubRewardedVideoManager.onRewardedVideoCompleted(CTAdapterRewardedVideo.class,
                        adUnitId,
                        MoPubReward.success(rewardName, amount));
                }
            });
        } else {
            MoPubLog.d("Attempted to show rewarded video before it was available.");
        }
    }


    @Override
    protected void onInvalidate() {
        video = null;
    }

}
