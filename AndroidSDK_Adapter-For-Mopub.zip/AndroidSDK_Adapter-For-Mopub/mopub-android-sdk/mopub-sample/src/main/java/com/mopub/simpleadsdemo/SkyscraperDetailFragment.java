package com.mopub.simpleadsdemo;

import com.amaze.com.R;

public class SkyscraperDetailFragment extends AbstractBannerDetailFragment {

    @Override
    public int getWidth() {
        return (int) getResources().getDimension(R.dimen.skyscraper_width);
    }

    @Override
    public int getHeight() {
        return (int) getResources().getDimension(R.dimen.skyscraper_height);
    }
}
