package com.mopub.simpleadsdemo;

import com.amaze.com.R;

public class LeaderboardDetailFragment extends AbstractBannerDetailFragment {

    @Override
    public int getWidth() {
        return (int) getResources().getDimension(R.dimen.leaderboard_width);
    }

    @Override
    public int getHeight() {
        return (int) getResources().getDimension(R.dimen.leaderboard_height);
    }
}
