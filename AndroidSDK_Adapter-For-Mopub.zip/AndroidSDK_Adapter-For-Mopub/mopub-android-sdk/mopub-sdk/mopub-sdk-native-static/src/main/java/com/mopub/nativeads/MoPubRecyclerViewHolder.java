package com.mopub.nativeads;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;

public class MoPubRecyclerViewHolder extends RecyclerView.ViewHolder {
    public MoPubRecyclerViewHolder(@NonNull final View itemView) {
        super(itemView);
    }
}
