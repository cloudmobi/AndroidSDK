package com.mopub.mobileads;

/**
 * Extend this class to mediate 3rd party rewarded playables.
 */
public abstract class CustomEventRewardedPlayable extends CustomEventRewardedAd {
}
