package com.mopub.mobileads;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import com.cloudtech.ads.callback.VideoAdLoadListener;
import com.cloudtech.ads.core.CTError;
import com.cloudtech.ads.core.CTService;
import com.cloudtech.ads.core.CTVideo;
import com.cloudtech.videoads.core.CTServiceVideo;
import com.cloudtech.videoads.core.VideoAdListener;
import com.mopub.common.LifecycleListener;
import com.mopub.common.logging.MoPubLog;

import java.util.Map;

public class CTAdapterRewardedVideo extends CustomEventRewardedVideo {

    private static boolean sInitialized = false;
    private static boolean sAdCached = false;
    private Context context;
    @Nullable
    private Activity mLauncherActivity;
    private CTVideo video;

    @Override
    @NonNull
    public LifecycleListener getLifecycleListener() {
        return null;
    }

    @Override
    @NonNull
    public String getAdNetworkId() {
        return "";
    }

    @Override
    public boolean checkAndInitializeSdk(@NonNull final Activity launcherActivity,
                                         @NonNull final Map<String, Object> localExtras,
                                         @NonNull final Map<String, String> serverExtras) throws Exception {
        String adunitId = null;

        if (CTHelper.extrasAreValid(serverExtras)) {
            adunitId = serverExtras.get(CTHelper.KEY_CT_SLOTID);
            CTService.init(launcherActivity, adunitId);
            return true;
        }
        return false;
    }

    @Override
    protected void loadWithSdkInitialized(@NonNull Activity activity,
                                          @NonNull Map<String, Object> localExtras,
                                          @NonNull Map<String, String> serverExtras)
            throws Exception {
        String adunitId = serverExtras.get(CTHelper.KEY_CT_SLOTID);
        context = activity.getApplicationContext();

        CTServiceVideo.preloadRewardedVideo(activity, adunitId,
                new VideoAdLoadListener() {
                    @Override
                    public void onVideoAdLoaded(CTVideo videoAd) {
                        MoPubRewardedVideoManager.onRewardedVideoLoadSuccess(CTAdapterRewardedVideo.class, "");

                        video = videoAd;
                    }



                    @Override
                    public void onVideoAdLoadFailed(CTError error) {
                        MoPubRewardedVideoManager.onRewardedVideoLoadFailure(null, "", MoPubErrorCode.NETWORK_NO_FILL);

                    }
                });
    }

    @Override
    public boolean hasVideoAvailable() {
        return CTServiceVideo.isRewardedVideoAvailable(video);
    }

    @Override
    public void showVideo() {
        if (hasVideoAvailable()) {
            CTServiceVideo.showRewardedVideo(video, new VideoAdListener() {
                @Override
                public void videoPlayBegin() {
                    Log.e("video", "videoPlayBegin: ");
                }


                @Override
                public void videoPlayFinished() {
                    Log.e("video", "videoPlayFinished: ");
                }


                @Override
                public void videoPlayError(Exception e) {
                    Log.e("video", "videoPlayError: ");
                }


                @Override
                public void videoClosed() {
                    Log.e("video", "videoClosed: ");
                }


                @Override
                public void onRewardedVideoAdRewarded(String rewardName, String rewardAmount) {
                    Log.e("video", "onRewardedVideoAdRewarded: ");
                }
            });
        } else {
            MoPubLog.d("Attempted to show Unity rewarded video before it was available.");
        }
    }

    @Override
    protected void onInvalidate() {
        video = null;
    }

}
