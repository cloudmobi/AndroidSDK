package com.mopub.mobileads;

import android.content.Context;

import com.cloudtech.ads.callback.CTAdEventListener;
import com.cloudtech.ads.core.CTNative;
import com.cloudtech.ads.core.CTService;
import com.cloudtech.ads.vo.AdsNativeVO;

import java.util.Map;

class CTAdapterFullScreen extends CustomEventInterstitial {

    private CustomEventInterstitialListener mInterstitialListener;
    private CTNative ctNative;

    /*
     * Abstract methods from CustomEventInterstitial
     */
    @Override
    protected void loadInterstitial(final Context context,
                                    final CustomEventInterstitialListener interstitialListener,
                                    final Map<String, Object> localExtras,
                                    final Map<String, String> serverExtras) {
        mInterstitialListener = interstitialListener;

        final String ctSlotId;

        if (extrasAreValid(serverExtras)) {
            ctSlotId = serverExtras.get(CTHelper.KEY_CT_SLOTID);
        } else {
            mInterstitialListener.onInterstitialFailed(MoPubErrorCode.INTERNAL_ERROR);
            return;
        }

        CTService.init(context, ctSlotId);


        // 获取插屏广告，返回一个含有广告的容器
        CTService.preloadInterstitial(ctSlotId, true, false, context,
                new CTAdEventListener() {

                    @Override
                    public void onInterstitialLoadSucceed(CTNative result) {
                    }


                    @Override
                    public void onAdviewGotAdSucceed(CTNative result) {
                        //在广告加载成功之后再show,不然会出一个空白
                        ctNative = result;
                        if (ctNative != null){
                            mInterstitialListener.onInterstitialLoaded();
                        } else {
                            mInterstitialListener.onInterstitialFailed(MoPubErrorCode.NETWORK_INVALID_STATE);
                        }
                    }

                    @Override
                    public void onAdviewGotAdFail(CTNative ctNative) {
                        mInterstitialListener.onInterstitialFailed(MoPubErrorCode.NETWORK_NO_FILL);
                    }

                    @Override
                    public void onAdviewIntoLandpage(CTNative ctNative) {

                    }

                    @Override
                    public void onStartLandingPageFail(CTNative ctNative) {

                    }

                    @Override
                    public void onAdviewDismissedLandpage(CTNative ctNative) {

                    }

                    @Override
                    public void onAdviewClicked(CTNative ctNative) {
                        mInterstitialListener.onInterstitialClicked();
                    }

                    @Override
                    public void onAdviewClosed(CTNative ctNative) {
                        mInterstitialListener.onInterstitialDismissed();
                    }

                    @Override
                    public void onAdviewDestroyed(CTNative ctNative) {

                    }

                    @Override
                    public void onAdsVoGotAdSucceed(AdsNativeVO adsNativeVO) {

                    }
                });


    }

    private static boolean extrasAreValid(Map<String, String> extras) {
        return extras.containsKey(CTHelper.KEY_CT_SLOTID);
    }

    @Override
    protected void showInterstitial() {
        if (ctNative != null && ctNative.isLoaded()) {
            CTService.showInterstitial(ctNative);
            mInterstitialListener.onInterstitialShown();
        } else {
            mInterstitialListener.onInterstitialFailed(MoPubErrorCode.NETWORK_INVALID_STATE);
        }
    }

    @Override
    protected void onInvalidate() {
        //mGreystripeAd.removeListener(this);
    }

}
