package com.mopub.mobileads;

import java.util.Map;

public class CTHelper {
    public static final String KEY_CT_SLOTID = "CT_SLOTID";

    public static boolean extrasAreValid(final Map<String, String> serverExtras) {
        return (serverExtras != null) && serverExtras.containsKey(CTHelper.KEY_CT_SLOTID);
    }

}
