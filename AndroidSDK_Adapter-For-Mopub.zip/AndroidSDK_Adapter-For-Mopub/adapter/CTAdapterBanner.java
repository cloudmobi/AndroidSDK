package com.mopub.mobileads;

import android.content.Context;
import android.view.Gravity;
import android.widget.LinearLayout;

import com.cloudtech.ads.callback.CTAdEventListener;
import com.cloudtech.ads.core.CTNative;
import com.cloudtech.ads.core.CTService;
import com.cloudtech.ads.vo.AdsNativeVO;

import java.util.Map;

public class CTAdapterBanner extends CustomEventBanner {

    private LinearLayout mInternalView;

    @Override
    protected void loadBanner(final Context context, final CustomEventBannerListener customEventBannerListener, Map<String, Object> localExtras, Map<String, String> serverExtras) {
        final String adunitId;

        if (extrasAreValid(serverExtras)) {
            adunitId = serverExtras.get(CTHelper.KEY_CT_SLOTID);
        } else {
            customEventBannerListener.onBannerFailed(MoPubErrorCode.INTERNAL_ERROR);
            return;
        }

        CTService.init(context, adunitId);

        mInternalView = new LinearLayout(context);

        LinearLayout.LayoutParams lp;
        lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.CENTER_HORIZONTAL;

        mInternalView.setLayoutParams(lp);

        AdViewController.setShouldHonorServerDimensions(mInternalView);

        CTService.getBanner(adunitId, false, context, new CTAdEventListener() {
            @Override
            public void onAdviewGotAdSucceed(CTNative ctNative) {
                if (ctNative != null) {
                    mInternalView.addView(ctNative);
                    customEventBannerListener.onBannerLoaded(mInternalView);
                } else {
                    customEventBannerListener.onBannerFailed(MoPubErrorCode.NETWORK_INVALID_STATE);
                }
            }

            @Override
            public void onInterstitialLoadSucceed(CTNative ctNative) {
            }

            @Override
            public void onAdviewGotAdFail(CTNative ctNative) {
                customEventBannerListener.onBannerFailed(MoPubErrorCode.NETWORK_NO_FILL);
            }

            @Override
            public void onAdviewIntoLandpage(CTNative ctNative) {
            }

            @Override
            public void onStartLandingPageFail(CTNative ctNative) {
            }

            @Override
            public void onAdviewDismissedLandpage(CTNative ctNative) {
            }

            @Override
            public void onAdviewClicked(CTNative ctNative) {
                customEventBannerListener.onBannerClicked();
            }

            @Override
            public void onAdviewClosed(CTNative ctNative) {
            }

            @Override
            public void onAdviewDestroyed(CTNative ctNative) {
            }

            @Override
            public void onAdsVoGotAdSucceed(AdsNativeVO adsNativeVO) {

            }
        });
    }

    @Override
    protected void onInvalidate() {
        mInternalView.removeAllViews();
        mInternalView = null;
    }

    private boolean extrasAreValid(final Map<String, String> serverExtras) {
        return (serverExtras != null) && serverExtras.containsKey(CTHelper.KEY_CT_SLOTID);
    }
}
