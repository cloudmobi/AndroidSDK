package com.mopub.mobileads;

import android.util.Log;
import android.widget.Toast;

import com.cloudtech.ads.callback.CTAdEventListener;
import com.cloudtech.ads.core.CTNative;
import com.cloudtech.ads.vo.AdsNativeVO;

public class MyCTAdEventListener implements CTAdEventListener {

    @Override
    public void onAdviewGotAdSucceed(CTNative result) {
        showMsg("onAdviewGotAdSucceed");
    }


    @Override
    public void onInterstitialLoadSucceed(CTNative result) {
        showMsg("onInterstitialLoadSucceed");
    }


    @Override
    public void onAdviewGotAdFail(CTNative result) {
        showMsg(result.getErrorsMsg());
        Log.i("sdksample", "==error==" + result.getErrorsMsg());
    }


    @Override
    public void onAdviewIntoLandpage(CTNative result) {
        showMsg("onAdviewIntoLandpage");
    }


    @Override
    public void onStartLandingPageFail(CTNative result) {
        showMsg("onStartLandingPageFail");
    }


    @Override
    public void onAdviewDismissedLandpage(CTNative result) {
        showMsg("onAdviewDismissedLandpage");
    }


    @Override
    public void onAdviewClicked(CTNative result) {
        showMsg("onAdviewClicked");
    }


    @Override
    public void onAdviewClosed(CTNative result) {
        showMsg("onAdviewClosed");
    }


    @Override
    public void onAdviewDestroyed(CTNative result) {
        showMsg("onAdviewDestroyed");
    }


    @Override
    public void onAdsVoGotAdSucceed(AdsNativeVO adsNativeVO) {
        showMsg("onAdsVoGotAdSucceed");
    }

    private void showMsg(String msg) {

        showToast(msg);
    }


    public static void showToast(String text) {
        android.util.Log.d("CT_AD_LISTENER", text);
    }


    private static Toast toast;

}
