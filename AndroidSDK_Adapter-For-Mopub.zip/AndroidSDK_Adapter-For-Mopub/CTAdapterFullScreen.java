package com.cloudtech.mediation.mopub;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import com.cloudtech.ads.callback.CTAdEventListener;
import com.cloudtech.ads.core.CTNative;
import com.cloudtech.ads.core.CTService;
import com.cloudtech.ads.vo.AdsNativeVO;
import com.mopub.mobileads.CustomEventInterstitial;
import com.mopub.mobileads.MoPubErrorCode;
import java.util.Map;

class CTAdapterFullScreen extends CustomEventInterstitial {

    private CustomEventInterstitialListener mInterstitialListener;
    private CTNative ctNative;

    private static final String TAG = "CTAdapterFullScreen";
    /*
     * Abstract methods from CustomEventInterstitial
     */
    @Override
    protected void loadInterstitial(final Context context,
                                    final CustomEventInterstitialListener interstitialListener,
                                    final Map<String, Object> localExtras,
                                    final Map<String, String> serverExtras) {
        mInterstitialListener = interstitialListener;
        final String ctSlotId;
        Log.e(TAG, "loadInterstitial: localExtras -> " + localExtras + ", serverExtras -> " + serverExtras);
        if (extrasAreValid(serverExtras) && context instanceof Activity) {
            ctSlotId = serverExtras.get(CTHelper.KEY_CT_SLOTID);
        } else {
            mInterstitialListener.onInterstitialFailed(MoPubErrorCode.INTERNAL_ERROR);
            return;
        }

        CTService.init(context, ctSlotId);
        CTService.preloadMRAIDInterstitial((Activity) context, ctSlotId, new CTAdEventListener() {

            @Override
            public void onInterstitialLoadSucceed(CTNative result) {
            }


            @Override
            public void onAdviewGotAdFail(CTNative ctNative) {
                mInterstitialListener.onInterstitialFailed(MoPubErrorCode.NETWORK_NO_FILL);
            }


            @Override
            public void onAdviewIntoLandpage(CTNative ctNative) {

            }


            @Override
            public void onStartLandingPageFail(CTNative ctNative) {

            }


            @Override
            public void onAdviewDismissedLandpage(CTNative ctNative) {

            }


            @Override
            public void onAdviewClicked(CTNative ctNative) {
                mInterstitialListener.onInterstitialClicked();
            }


            @Override
            public void onAdviewClosed(CTNative ctNative) {
                mInterstitialListener.onInterstitialDismissed();
            }


            @Override
            public void onAdviewDestroyed(CTNative ctNative) {

            }


            @Override
            public void onAdviewGotAdSucceed(CTNative result) {
                //在广告加载成功之后再show,不然会出一个空白
                ctNative = result;

                mInterstitialListener.onInterstitialLoaded();
            }


            @Override
            public void onAdsVoGotAdSucceed(AdsNativeVO adsNativeVO) {

            }
        });

    }


    private static boolean extrasAreValid(Map<String, String> extras) {
        return extras.containsKey(CTHelper.KEY_CT_SLOTID);
    }


    @Override
    protected void showInterstitial() {
        if (CTService.isInterstitialAvailable(ctNative)) {
            CTService.showInterstitial(ctNative);
            mInterstitialListener.onInterstitialShown();
        } else {
            mInterstitialListener.onInterstitialFailed(MoPubErrorCode.NETWORK_INVALID_STATE);
        }
    }


    @Override
    protected void onInvalidate() {
        //mGreystripeAd.removeListener(this);
    }

}
