package com.cloudtech.mediation.mopub;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import com.cloudtech.ads.callback.CTAdEventListener;
import com.cloudtech.ads.core.CTAdvanceNative;
import com.cloudtech.ads.core.CTNative;
import com.cloudtech.ads.core.CTService;
import com.cloudtech.ads.enums.CTImageRatioType;
import com.cloudtech.ads.vo.AdsNativeVO;
import com.mopub.nativeads.CustomEventNative;
import com.mopub.nativeads.ImpressionTracker;
import com.mopub.nativeads.NativeErrorCode;
import com.mopub.nativeads.NativeImageHelper;
import com.mopub.nativeads.StaticNativeAd;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CTAdapterNative extends CustomEventNative {

    @Override
    protected void loadNativeAd(
        @NonNull Context context,
        @NonNull final CustomEventNativeListener customEventNativeListener,
        @NonNull Map<String, Object> localExtras, @NonNull Map<String, String> serverExtras) {
        final String adunitId;

        if (extrasAreValid(serverExtras)) {
            adunitId = serverExtras.get(CTHelper.KEY_CT_SLOTID);
        } else {
            customEventNativeListener.onNativeAdFailed(
                NativeErrorCode.NATIVE_ADAPTER_CONFIGURATION_ERROR);
            return;
        }

        CTService.init(context, adunitId);

        new YeahMobiStaticNativeAd(context, adunitId, new ImpressionTracker(context),
            customEventNativeListener);
    }


    class YeahMobiStaticNativeAd extends StaticNativeAd {
        private final ImpressionTracker mImpressionTracker;
        private final CustomEventNativeListener mCustomEventNativeListener;
        private CTAdvanceNative mCTAdvanceNative;


        public YeahMobiStaticNativeAd(final Context context, String adunitId, final ImpressionTracker impressionTracker, CustomEventNativeListener customEventNativeListener) {
            mImpressionTracker = impressionTracker;
            mCustomEventNativeListener = customEventNativeListener;

            CTService.getAdvanceNative(adunitId, context, CTImageRatioType.RATIO_19_TO_10,
                new CTAdEventListener() {

                    @Override
                    public void onAdviewGotAdSucceed(CTNative result) {
                        if (result == null) {
                            mCustomEventNativeListener.onNativeAdFailed(
                                NativeErrorCode.NETWORK_NO_FILL);
                            return;
                        }

                        mCTAdvanceNative = (CTAdvanceNative) result;

                        setIconImageUrl(mCTAdvanceNative.getIconUrl());
                        setMainImageUrl(mCTAdvanceNative.getImageUrl());

                        setTitle(mCTAdvanceNative.getTitle());
                        setCallToAction(mCTAdvanceNative.getButtonStr());
                        setText(mCTAdvanceNative.getDesc());

                        setPrivacyInformationIconImageUrl(mCTAdvanceNative.getAdChoiceIconUrl());
                        setPrivacyInformationIconClickThroughUrl(
                            mCTAdvanceNative.getAdChoiceLinkUrl());

                        final List<String> imageUrls = new ArrayList<>();

                        imageUrls.add(mCTAdvanceNative.getImageUrl());
                        imageUrls.add(mCTAdvanceNative.getIconUrl());

                        NativeImageHelper.preCacheImages(context, imageUrls,
                            new NativeImageHelper.ImageListener() {
                                @Override
                                public void onImagesCached() {
                                    mCustomEventNativeListener.onNativeAdLoaded(
                                        YeahMobiStaticNativeAd.this);
                                }


                                @Override
                                public void onImagesFailedToCache(NativeErrorCode errorCode) {
                                    mCustomEventNativeListener.onNativeAdFailed(errorCode);
                                }
                            });
                    }


                    @Override
                    public void onInterstitialLoadSucceed(CTNative ctNative) {
                    }


                    @Override
                    public void onAdviewGotAdFail(CTNative result) {
                        mCustomEventNativeListener.onNativeAdFailed(
                            NativeErrorCode.NETWORK_NO_FILL);
                    }


                    @Override
                    public void onAdviewIntoLandpage(CTNative ctNative) {
                    }


                    @Override
                    public void onStartLandingPageFail(CTNative ctNative) {
                    }


                    @Override
                    public void onAdviewDismissedLandpage(CTNative ctNative) {
                    }


                    @Override
                    public void onAdviewClicked(CTNative result) {
                        notifyAdClicked();
                    }


                    @Override
                    public void onAdviewClosed(CTNative ctNative) {
                    }


                    @Override
                    public void onAdviewDestroyed(CTNative ctNative) {
                    }


                    @Override
                    public void onAdsVoGotAdSucceed(AdsNativeVO adsNativeVO) {

                    }
                });
        }


        @Override
        public void prepare(final View view) {
            mCTAdvanceNative.registeADClickArea(view);
            mImpressionTracker.addView(view, this);
        }


        @Override
        public void clear(@NonNull View view) {
            mCTAdvanceNative.unRegisterAdClickArea();
            mImpressionTracker.removeView(view);
        }


        @Override
        public void recordImpression(final View view) {
            notifyAdImpressed();
        }


        @Override
        public void destroy() {
            mImpressionTracker.destroy();
        }
    }


    private boolean extrasAreValid(final Map<String, String> serverExtras) {
        return (serverExtras != null) && serverExtras.containsKey(CTHelper.KEY_CT_SLOTID);
    }
}
