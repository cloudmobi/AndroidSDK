package com.cloudtech.mediation.admob;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import com.cloudtech.ads.callback.CTAdEventListener;
import com.cloudtech.ads.core.CTNative;
import com.cloudtech.ads.core.CTService;
import com.cloudtech.ads.vo.AdsNativeVO;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.mediation.MediationAdRequest;
import com.google.android.gms.ads.mediation.customevent.CustomEventBanner;
import com.google.android.gms.ads.mediation.customevent.CustomEventBannerListener;

/**
 * Created by Vincent
 * Email:jingwei.zhang@yeahmobi.com
 */
public class CTCustomEventBanner implements CustomEventBanner {

    private static final String TAG = "CTCustomEventBanner";
    private CustomEventBannerListener customEventBannerListener;
    private ViewGroup decorView;
    private LinearLayout viewGroup;
    @Override
    public void requestBannerAd(Context context, CustomEventBannerListener customEventBannerListener,
                                String serverParameter, AdSize adSize, MediationAdRequest mediationAdRequest, Bundle bundle) {
        this.customEventBannerListener = customEventBannerListener;
        Log.e(TAG, "requestBannerAd: Admob -> " + serverParameter);
        if (!(context instanceof Activity)) {
            Log.w(TAG, "Context must be of type Activity.");
            if (customEventBannerListener != null) {
                customEventBannerListener.onAdFailedToLoad(AdRequest.ERROR_CODE_NO_FILL);
            }
            return;
        }
        CTService.init(context, serverParameter);
        Log.e(TAG, "requestBannerAd: " + serverParameter);

        decorView = (ViewGroup) (((Activity) context).getWindow().getDecorView());

        viewGroup = new LinearLayout(context);

        com.cloudtech.ads.enums.AdSize ctAdSize = com.cloudtech.ads.enums.AdSize.AD_SIZE_320X50;
        viewGroup.setLayoutParams(new ViewGroup.LayoutParams(dpToPx(adSize.getWidth()),dpToPx(adSize.getHeight())));
        viewGroup.setBackgroundColor(Color.TRANSPARENT);
        decorView.addView(viewGroup);

        CTService.getMRAIDBanner((Activity) context, serverParameter, viewGroup, ctAdSize, ctAdEventListener);
    }


    @Override
    public void onDestroy() {

    }


    @Override
    public void onPause() {

    }


    @Override
    public void onResume() {

    }


    private CTAdEventListener ctAdEventListener = new CTAdEventListener() {
        @Override
        public void onAdviewGotAdSucceed(CTNative result) {
            if (viewGroup != null) {
                decorView.removeView(viewGroup);
            }
            if (customEventBannerListener != null) {
                customEventBannerListener.onAdLoaded(result);
                customEventBannerListener.onAdOpened();
            }
        }


        @Override
        public void onAdsVoGotAdSucceed(AdsNativeVO result) {

        }


        @Override
        public void onInterstitialLoadSucceed(CTNative result) {
        }


        @Override
        public void onAdviewGotAdFail(CTNative result) {
            if (customEventBannerListener != null) {
                customEventBannerListener.onAdFailedToLoad(AdRequest.ERROR_CODE_NO_FILL);
            }
        }


        @Override
        public void onAdviewIntoLandpage(CTNative result) {

        }


        @Override
        public void onStartLandingPageFail(CTNative result) {

        }


        @Override
        public void onAdviewDismissedLandpage(CTNative result) {

        }


        @Override
        public void onAdviewClicked(CTNative result) {

        }


        @Override
        public void onAdviewClosed(CTNative result) {
            if (customEventBannerListener != null) {
                customEventBannerListener.onAdClosed();
            }
        }


        @Override
        public void onAdviewDestroyed(CTNative result) {

        }
    };

    private int dpToPx(int dp) {
        DisplayMetrics displayMetrics = Resources.getSystem().getDisplayMetrics();
        return (int) (dp * displayMetrics.density + .5f);
    }
}
