package com.cloudtech.mediation.admob;

import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;

import com.cloudtech.ads.callback.CTAdEventListener;
import com.cloudtech.ads.core.CTNative;
import com.cloudtech.ads.core.CTService;
import com.cloudtech.ads.vo.AdsNativeVO;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.mediation.MediationAdRequest;
import com.google.android.gms.ads.mediation.customevent.CustomEventBanner;
import com.google.android.gms.ads.mediation.customevent.CustomEventBannerListener;

public class CTCustomEventBanner implements CustomEventBanner {

    private static final String TAG = "CTCustomEventBanner";
    private CustomEventBannerListener customEventBannerListener;

    @Override
    public void requestBannerAd(Context context, CustomEventBannerListener customEventBannerListener,
                                String serverParameter, AdSize adSize, MediationAdRequest mediationAdRequest, Bundle bundle) {
        this.customEventBannerListener = customEventBannerListener;
        Log.i(TAG, "requestBannerAd: Admob -> " + serverParameter);

        CTService.init(context, serverParameter);
        Log.i(TAG, "requestBannerAd: " + serverParameter);

        com.cloudtech.ads.enums.AdSize ctAdSize = com.cloudtech.ads.enums.AdSize.AD_SIZE_320X50;
        CTService.getMRAIDBanner(context, serverParameter, ctAdSize, ctAdEventListener);
    }


    @Override
    public void onDestroy() {

    }


    @Override
    public void onPause() {

    }


    @Override
    public void onResume() {

    }


    private CTAdEventListener ctAdEventListener = new CTAdEventListener() {
        @Override
        public void onAdviewGotAdSucceed(CTNative result) {
            if (customEventBannerListener != null) {
                customEventBannerListener.onAdLoaded(result);
                customEventBannerListener.onAdOpened();
            }
        }


        @Override
        public void onAdsVoGotAdSucceed(AdsNativeVO result) {

        }


        @Override
        public void onInterstitialLoadSucceed(CTNative result) {
        }


        @Override
        public void onAdviewGotAdFail(CTNative result) {
            if (customEventBannerListener != null) {
                customEventBannerListener.onAdFailedToLoad(AdRequest.ERROR_CODE_NO_FILL);
            }
        }


        @Override
        public void onAdviewIntoLandpage(CTNative result) {

        }


        @Override
        public void onStartLandingPageFail(CTNative result) {

        }


        @Override
        public void onAdviewDismissedLandpage(CTNative result) {

        }


        @Override
        public void onAdviewClicked(CTNative result) {

        }


        @Override
        public void onAdviewClosed(CTNative result) {
            if (customEventBannerListener != null) {
                customEventBannerListener.onAdClosed();
            }
        }


        @Override
        public void onAdviewDestroyed(CTNative result) {

        }
    };

    private int dpToPx(int dp) {
        DisplayMetrics displayMetrics = Resources.getSystem().getDisplayMetrics();
        return (int) (dp * displayMetrics.density + .5f);
    }
}
