package com.cloudtech.mediation.admob;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import com.cloudtech.ads.callback.CTAdEventListener;
import com.cloudtech.ads.core.CTNative;
import com.cloudtech.ads.core.CTService;
import com.cloudtech.ads.vo.AdsNativeVO;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.mediation.MediationAdRequest;
import com.google.android.gms.ads.mediation.customevent.CustomEventInterstitial;
import com.google.android.gms.ads.mediation.customevent.CustomEventInterstitialListener;

public class CTCustomEventInterstitial implements CustomEventInterstitial {
    private CTNative result;
    private static final String TAG = "CTCustomInterstitial";
    private CustomEventInterstitialListener interstitialListener;

    @Override
    public void requestInterstitialAd(Context context, CustomEventInterstitialListener customEventInterstitialListener, String serverParameter, MediationAdRequest mediationAdRequest, Bundle bundle) {
        interstitialListener = customEventInterstitialListener;
        Log.e(TAG, "requestInterstitialAd: Admob -> " + serverParameter);
        if (!(context instanceof Activity)) {
            Log.w(TAG, "Context must be of type Activity.");
            if (interstitialListener != null) {
                interstitialListener.onAdFailedToLoad(AdRequest.ERROR_CODE_NO_FILL);
            }
            return;
        }
        CTService.init(context, serverParameter);
        CTService.preloadMRAIDInterstitial((Activity) context, serverParameter, ctAdEventListener);
    }


    @Override
    public void showInterstitial() {
        if (!CTService.isInterstitialAvailable(result)) {
            if (interstitialListener != null) {
                interstitialListener.onAdFailedToLoad(AdRequest.ERROR_CODE_INTERNAL_ERROR);
            }
            return;
        }
        CTService.showInterstitial(result);
    }


    @Override
    public void onDestroy() {

    }


    @Override
    public void onPause() {

    }


    @Override
    public void onResume() {

    }


    private CTAdEventListener ctAdEventListener = new CTAdEventListener() {
        @Override
        public void onAdviewGotAdSucceed(CTNative result) {
            if (interstitialListener != null) {
                interstitialListener.onAdLoaded();
            }
            CTCustomEventInterstitial.this.result = result;

        }


        @Override
        public void onAdsVoGotAdSucceed(AdsNativeVO result) {

        }


        @Override
        public void onInterstitialLoadSucceed(CTNative result) {
            if (interstitialListener != null) {
                interstitialListener.onAdOpened();
            }
        }


        @Override
        public void onAdviewGotAdFail(CTNative result) {
            if (interstitialListener != null) {
                interstitialListener.onAdFailedToLoad(AdRequest.ERROR_CODE_NO_FILL);
            }
        }


        @Override
        public void onAdviewIntoLandpage(CTNative result) {

        }


        @Override
        public void onStartLandingPageFail(CTNative result) {

        }


        @Override
        public void onAdviewDismissedLandpage(CTNative result) {

        }


        @Override
        public void onAdviewClicked(CTNative result) {

        }


        @Override
        public void onAdviewClosed(CTNative result) {
            if (interstitialListener != null) {
                interstitialListener.onAdClosed();
            }
        }


        @Override
        public void onAdviewDestroyed(CTNative result) {

        }
    };
}
